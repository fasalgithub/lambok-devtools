package com.springboot.lambokanddevtools;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LambokanddevtoolsApplicationTests {

	@Test
	void contextLoads() {
	}

}
