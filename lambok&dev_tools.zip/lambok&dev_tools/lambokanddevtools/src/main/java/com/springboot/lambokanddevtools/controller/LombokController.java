package com.springboot.lambokanddevtools.controller;

import java.time.LocalDate;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.springboot.lambokanddevtools.Bean.Alien;

@RestController
public class LombokController 
{
	@RequestMapping(value = "/alliens",method = RequestMethod.GET)
	public Alien getMyAllien() 
	{
            Alien alien = new Alien(101,"alien caption",22);
	    return alien;
	}

	@RequestMapping("/date")
	public ModelAndView getMyData(Model model) 
	{
		ModelAndView modelAndView = new ModelAndView();
		
		LocalDate loaDate = LocalDate.now();
		modelAndView.setViewName("currentdate");
//		modelAndView.addObject("date", loaDate);
		modelAndView.addObject("date", "jsdjsdjnj");
		
		return modelAndView;
		
	}
}
