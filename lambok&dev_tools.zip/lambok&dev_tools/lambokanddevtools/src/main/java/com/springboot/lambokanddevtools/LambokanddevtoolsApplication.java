package com.springboot.lambokanddevtools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LambokanddevtoolsApplication {

	public static void main(String[] args) 
	{
		SpringApplication.run(LambokanddevtoolsApplication.class, args);
	}

}
